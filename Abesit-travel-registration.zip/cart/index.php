<?php 
// $insert = false;
if(isset($_POST['name'])){
   $server = "localhost";
   $username = "root";
   $password = "";
    $database = "trip";
    $port = "3307";


   $con = mysqli_connect($server,$username,$password,$database,$port);

   if(!$con){
    die("database connection failed due to" . mysqli_connect_error());
   }
//    echo "Db connected successfully";
   
// $name=$_POST['name'];
// $age=$_POST['age'];
// $gender=$_POST['gender'];
// $phone=$_POST['phone'];
// $desc=$_POST['desc'];

$name = isset($_POST['name']) ? $_POST['name'] : '';
$age = isset($_POST['age']) ? $_POST['age'] : '';
$gender = isset($_POST['gender']) ? $_POST['gender'] : '';
$phone = isset($_POST['phone']) ? $_POST['phone'] : '';
$desc = isset($_POST['desc']) ? $_POST['desc'] : '';


 $sql = "INSERT INTO `trip`.`Abesit` (`name`, `age`, `sex`, `phone`, `other`, `dt`) VALUES ('$name', '$age', '$gender', '$phone', '$desc', current_timestamp());";

// echo $sql;

if($con->query($sql)==true){
    echo "Successfully Inserted";
   }else{
echo "ERROR: $sql <br> $con->error";
}

$con->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Travel form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <img class="Abesit" src="Abesit.webp" alt="ABESIT">
    <div class="container">
        <h1>WELCOME to ABESIT  US Trip form</h1>
        <p>Enter your details and submit this form  to confirm your participation in the trip</p>
        <!-- <?php
       echo "<p class='submitMsg'>Thanks for submittting the form</p>";
        ?> -->
        <form action="index.php" method="post">
            <input type="text" name="name" id="name" placeholder="Enter your name">
            <input type="text" name="age" id="age" placeholder="Enter your age">
            <input type="text" name="gender" id="gender" placeholder="Enter your sex">
            <!-- <input type="text" name="email" id="email" placeholder="Enter your email"> -->
            <input type="text" name="phone" id="phone" placeholder="Enter your phone">
            <textarea name="desc" id="desc" cols="30" rows="10" placeholder="Enter any other information here"></textarea>
            
            <button class="btn">submit</button>
           

        </form>
    </div>
   <script src="index.js">
    // INSERT INTO `abesit` (`id`, `name`, `age`, `sex`, `phone`, `other`, `dt`) VALUES ('1', 'Anuj Kumar', '22', 'male', '9336580251', 'This information is given by myside which correct and absolutely correct.', current_timestamp());

   </script>
</body>
</html>
